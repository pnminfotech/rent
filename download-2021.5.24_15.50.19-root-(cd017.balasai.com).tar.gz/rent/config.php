<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    function dbConfig() {
        $this -> serverName = 'localhost';
        $this -> userName = 'root';
        $this -> password = "6WjuW+YX:J\\O8:i4\\I;f;7@r";
        $this -> dbName = "rent";
    }
}
?>