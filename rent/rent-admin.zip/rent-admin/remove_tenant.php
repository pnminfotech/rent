
<?php 
include 'dbConfig.php';
$id=$_REQUEST["id"];

$query111 = "select * from flat_rental where id=$id";
$result111 = mysqli_query($conn,$query111) or die ( mysqli_error($conn));
$row111=mysqli_fetch_assoc($result111);
$building_name = $row111['building_name'];
$flat_no  = $row111['flat_no'];
$wing = $row111['wing'];
$b_id = $row111['b_id'];
$status='Empty';
$inss5="UPDATE flat_details SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
$query23=mysqli_query($conn,$inss5)  or die(mysqli_error($conn));
if($query23==1)
{
    $inss15="UPDATE rent_update_details SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
    mysqli_query($conn,$inss15)  or die(mysqli_error($conn));
    if(mysqli_affected_rows($conn) > 0){
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'"';
        echo 'alert("Remove Tenant");';
        echo '</script>';    
    }
    else{
      echo '<script language="javascript">';
   echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'";';
     echo 'alert("Remove Tenant1");';
      echo '</script>';
      mysqli_error($conn);        
    }
}
if($query23==1)
{
    $inss15="UPDATE flat_rental SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
    mysqli_query($conn,$inss15)  or die(mysqli_error($conn));
    if(mysqli_affected_rows($conn) > 0){
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'"';
        echo 'alert("Remove Tenant");';
        echo '</script>';
    }
    else{
         echo '<script language="javascript">';
          echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'";';
       echo 'alert("Remove Tenant1");';
         echo '</script>';
        mysqli_error($conn);
    }
}
    if(mysqli_affected_rows($conn) > 0){
        echo '<script language="javascript">';
     echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'"';
        echo 'alert("Remove Tenant");';
        echo '</script>';
        
    }
    else{
          echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'";';
        echo 'alert("Remove Tenant1");';
          echo '</script>';
        mysqli_error($conn);   
        
    }



?> 
<?php /*
include 'dbConfig.php';
$id=$_REQUEST["id"];

$query111 = "select * from flat_rental where id=$id";
$result111 = mysqli_query($conn,$query111) or die ( mysqli_error($conn));
$row111=mysqli_fetch_assoc($result111);
$building_name = $row111['building_name'];
$flat_no  = $row111['flat_no'];
$wing = $row111['wing'];
$b_id = $row111['b_id'];
$status='Empty';
$inss5="UPDATE flat_details SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
$query23=mysqli_query($conn,$inss5)  or die(mysqli_error($conn));
if($query23==1)
{
    $inss5="UPDATE rent_update_details SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
    $query2=mysqli_query($conn,$inss5)  or die(mysqli_error($conn));
    if($query2==1)
    {
        $inss5="UPDATE flat_rental SET status='$status'  WHERE building_name='".$building_name."' and flat_no='".$flat_no."' and wing='".$wing."'";
        $query3=mysqli_query($conn,$inss5)  or die(mysqli_error($conn));
 
    if(mysqli_affected_rows($conn)){
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'"';
        echo 'alert("Remove Tenant");';
        echo '</script>';
        
    }
    else{
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'";';
        echo 'alert("Remove Tenant");';
        echo '</script>';
        
    }
    }
    if(mysqli_affected_rows($conn)){
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'"';
        echo 'alert("Remove Tenant");';
        echo '</script>';
        
    }
    else{
        echo '<script language="javascript">';
        echo 'location.href="view-tenant-flat-main-info.php?flat_no='.$flat_no.'&building_name='.$building_name.'&b_id='.$b_id.'&wing='.$wing.'";';
        echo 'alert("Remove Tenant");';
        echo '</script>';
        
    }
}


*/?> 